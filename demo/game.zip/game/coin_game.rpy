init python:
    import time

    class CoinGameState:
        def __init__(self, duration=30.0):
            self.duration = duration
            self.score = 0
            self.coins = []
            self.started = None
            self.next_spawn = 0.0
            self.remaining = duration
            self.next_id = 0
            self.feedback = []

            # 硬幣的點擊區域大小。
            self.coin_size = 100

        def update(self):
            now = time.monotonic()
            self.feedback = [item for item in self.feedback if now < item["expires"]]

            if self.started is None:
                self.started = now

            elapsed = now - self.started
            self.remaining = max(0.0, self.duration - elapsed)

            # 移除已超過停留時間的硬幣。
            self.coins = [
                coin for coin in self.coins
                if now < coin["expires"]
            ]

            if self.remaining <= 0:
                return

            if elapsed >= self.next_spawn:
                self.next_spawn = elapsed + 1.0
                self.spawn_coin(now)

        def spawn_coin(self, now):
            size = self.coin_size

            # 保留上方分數區域，以及畫面四周的邊界。
            min_x = 40
            max_x = int(config.screen_width) - size - 40
            min_y = 160
            max_y = int(config.screen_height) - size - 40

            if max_x < min_x or max_y < min_y:
                return

            # 嘗試找出不與其他硬幣重疊的位置。
            for attempt in range(40):
                x = renpy.random.randint(min_x, max_x)
                y = renpy.random.randint(min_y, max_y)

                overlaps = any(
                    abs(x - coin["x"]) < size + 15
                    and abs(y - coin["y"]) < size + 15
                    for coin in self.coins
                )

                if not overlaps:
                    break
            else:
                # 找不到空位時，略過這次生成。
                return

            color, points = renpy.random.choice([
                ("#FFD34E", 300),   # 金色
                ("#D0D7E0", 200),   # 銀色
                ("#C88448", 100),   # 銅色
            ])

            self.coins.append({
                "id": self.next_id,
                "x": x,
                "y": y,
                "color": color,
                "points": points,
                "expires": now + 2.5,
            })

            self.next_id += 1

        def collect(self, coin_id):
            now = time.monotonic()

            # 時間已到就不能再得分。
            if self.started is None:
                return

            if now - self.started >= self.duration:
                return

            for coin in self.coins:
                if coin["id"] == coin_id:
                    # 再檢查一次期限，避免點到剛過期的硬幣。
                    if now < coin["expires"]:
                        self.score += coin["points"]
                        self.feedback.append(dict(coin, expires=now + 0.7))
                        renpy.sound.play("audio/coin_collect.ogg")

                    self.coins.remove(coin)
                    break


screen coin_game(duration=30.0):
    modal True

    default state = CoinGameState(duration)

    # 不讓鍵盤焦點選中硬幣後，透過 Enter 得分。
    key "focus_left" action NullAction()
    key "focus_right" action NullAction()
    key "focus_up" action NullAction()
    key "focus_down" action NullAction()
    key "button_select" action NullAction()

    key "rollback" action NullAction()
    key "game_menu" action NullAction()

    # 更新硬幣生成、消失與剩餘時間。
    timer 0.05 repeat True action Function(state.update)

    # 整場時間到，將分數回傳給劇情。
    timer duration action Return(state.score)

    add Solid("#182132")

    vbox:
        xpos 40
        ypos 25
        spacing 8

        text "營業額：[state.score]" size 36 color "#FFFFFF"
        text "剩餘時間：[state.remaining:.1f] 秒" size 26 color "#FFFFFF"

    text "金 +300　銀 +200　銅 +100":
        xalign 0.97
        ypos 35
        size 28
        color "#FFFFFF"

    button:
            xpos 1700
            ypos 950
            xysize (200, 100)
            padding(0, 0)
            background "black"
            hover_background color("#b870a7")
            text "skip":
                align((0.5, 0.5))

            action Return(state.score)

    # index 讓其他硬幣消失後，仍能辨認每一枚硬幣。
    for coin index coin["id"] in state.coins:

        button:
            xpos coin["x"]
            ypos coin["y"]
            xysize (state.coin_size, state.coin_size)
            padding (0, 0)
            background None
            hover_background None

            action Function(state.collect, coin["id"])

            fixed:
                # 暫時用圓形字元代替硬幣圖片。
                text "●":
                    font "DejaVuSans.ttf"
                    size 100
                    color coin["color"]
                    align (0.5, 0.5)

                text str(coin["points"]):
                    size 30
                    color "#302718"
                    align (0.5, 0.5)

    # 每個回饋以硬幣 id 保留獨立動畫，不受後續點擊重設。
    for item index item["id"] in state.feedback:
        fixed:
            xpos item["x"]
            ypos item["y"]
            xysize (state.coin_size, state.coin_size)
            text "●":
                font "DejaVuSans.ttf"
                size 100
                color item["color"]
                align (0.5, 0.5)
                at demo_coin_collect
            text ("+%d" % item["points"]):
                size 42
                color item["color"]
                outlines [(2, "#182132", 0, 0)]
                align (0.5, 0.5)
                at demo_coin_popup

screen coin_game_result(score):
    modal True
    key "rollback" action NullAction()
    key "game_menu" action NullAction()

    add Solid("#182132")

    vbox:
        xpos 40
        ypos 25
        spacing 8
        text "營業額：[score]" size 36 color "#FFFFFF"
        text "結算完成" size 26 color "#FFFFFF"

    vbox:
        align (0.5, 0.5)
        spacing 35
        text "點算結束！" size 48 color "#FFFFFF" xalign 0.5
        text "棠今天賺了 [score] 元。" size 60 color "#FFD34E" xalign 0.5
        textbutton "繼續":
            xalign 0.5
            padding (40, 18)
            background Solid("#30415E")
            hover_background Solid("#526C94")
            text_size 36
            text_color "#FFFFFF"
            action Return()

# 從原本的劇情呼叫這段即可。
label play_coin_game:

    "在 30 秒內，用滑鼠點擊硬幣點算營業額。"
    "金色 300 元、銀色 200 元、銅色 100 元。點擊繼續後開始！"

    window hide

    $ coin_old_quick_menu = quick_menu
    $ quick_menu = False

    call screen coin_game(duration=30.0)

    # 保留總分，之後可以用來判斷劇情分支。
    $ coin_total_score = _return

    call screen coin_game_result(coin_total_score)

    $ quick_menu = coin_old_quick_menu
    $ renpy.block_rollback()

    # 保持對話框隱藏，直接銜接 CG。
    return
