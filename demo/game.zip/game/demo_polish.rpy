# 配音字幕節奏：語音與字幕結束後等待三秒；仍可手動點擊。
default demo_dialogue_text_ready = False
default demo_dialogue_idle_since = None

init -10 python:
    import time as demo_clock
    def demo_dialogue_callback(event, interact=True, **kwargs):
        if not interact:
            return
        if event == "begin":
            store.demo_dialogue_text_ready = False
            store.demo_dialogue_idle_since = None
            renpy.show_screen("demo_dialogue_clock")
        elif event == "slow_done":
            store.demo_dialogue_text_ready = True
        elif event == "end":
            renpy.hide_screen("demo_dialogue_clock")

    def demo_dialogue_tick():
        if not store.demo_dialogue_text_ready or renpy.music.is_playing(channel="voice"):
            store.demo_dialogue_idle_since = None
            return
        now = demo_clock.monotonic()
        if store.demo_dialogue_idle_since is None:
            store.demo_dialogue_idle_since = now
        elif now - store.demo_dialogue_idle_since >= 3.0:
            renpy.end_interaction(True)

screen demo_dialogue_clock():
    timer 0.05 repeat True action Function(demo_dialogue_tick)

transform demo_speaking:
    linear 0.18 matrixcolor BrightnessMatrix(0.0)

transform demo_listening:
    linear 0.18 matrixcolor BrightnessMatrix(-0.25)

transform demo_coin_popup:
    alpha 1.0
    yoffset 0
    parallel:
        easeout 0.65 yoffset -85
    parallel:
        pause 0.2
        linear 0.45 alpha 0.0

transform demo_coin_collect:
    alpha 1.0
    zoom 1.0
    linear 0.25 zoom 0.3 alpha 0.0
