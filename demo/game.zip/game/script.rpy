# 依照 Google Sheets「demo 劇本」編號 1～12 排列。

define c = Character("青", callback=demo_dialogue_callback)
define t = Character("棠", callback=demo_dialogue_callback)

image c shy = "images/c/shy.png"
image t nom = "images/t/nom.png"

# cg01 的對話背景沿用原專案的循環影片。
init python:
    renpy.music.register_channel("demo_cg_video", mixer="sfx", movie=True)

    def demo_check_cg_loop():
        # 在每次計時器觸發時重新讀取影片，不使用畫面建立時的舊值。
        playing = renpy.music.get_playing(channel="demo_cg_video")
        if playing and playing.replace("\\", "/").lower().endswith("images/gif01.webm"):
            renpy.end_interaction(True)

    def demo_finish_cg_intro():
        playing = renpy.music.get_playing(channel="demo_cg_video")
        if not playing or not playing.replace("\\", "/").lower().endswith("images/gif01.webm"):
            renpy.music.play("images/GIF01.webm", channel="demo_cg_video", loop=True)
        renpy.end_interaction(True)

# 兩段影片共用同一個顯示物件與頻道，不在交界處更換場景。
image cg01 = Movie(channel="demo_cg_video", group="demo_cg")

screen demo_wait_cg_intro():
    modal True
    key "rollback" action NullAction()
    key "game_menu" action NullAction()
    key "dismiss" action NullAction()
    textbutton "跳過動畫":
        xalign 0.97
        yalign 0.05
        padding (25, 15)
        background Solid("#182132CC")
        hover_background Solid("#526C94EE")
        text_size 28
        text_color "#FFFFFF"
        action [Function(renpy.music.play, "images/GIF01.webm", channel="demo_cg_video", loop=True), Return()]
    timer 0.02 repeat True action Function(demo_check_cg_loop)
    # cg01.webm 長度 15.816 秒；若播放後端未回報切換，仍自動接上 GIF。
    timer 16.0 action Function(demo_finish_cg_intro)

transform demo_marquee_motion:
    xalign 0.5
    yalign 0.5
    xoffset -config.screen_width
    linear 2.0 xoffset 0
    pause 3.0
    linear 2.0 xoffset config.screen_width

screen demo_marquee(message):
    text message:
        size 100
        color "#f9f9f9"
        outlines [(2, "#f9f9f9", 0, 0)]
        at demo_marquee_motion

# 將位置、大小與亮暗放在同一個變換，避免縮放重複套用。
transform demo_c_portrait(brightness=0.0):
    xalign 0.2
    yalign 1.0
    zoom 0.33
    xoffset 0
    linear 0.18 matrixcolor BrightnessMatrix(brightness)

transform demo_t_portrait(brightness=0.0):
    xalign 0.8
    yalign 1.0
    zoom 0.33
    xoffset 0
    linear 0.18 matrixcolor BrightnessMatrix(brightness)

transform demo_c_position:
    xalign 0.2
    yalign 1.0
    zoom 0.33

transform demo_c_exit:
    matrixcolor BrightnessMatrix(0.0)
    xalign 0.2
    yalign 1.0
    zoom 0.33
    xoffset 0
    linear 1.0 xoffset -config.screen_width

transform demo_t_position:
    xalign 0.8
    yalign 1.0
    zoom 0.33

# 橘色項目共用字幕流程，傳入各自的文字。
label demo_show_marquee(message):
    window hide
    show screen demo_marquee(message)
    pause 7.0
    hide screen demo_marquee
    return

label start:
    # 1：開場跑馬燈。
    scene black
    call demo_show_marquee("試玩版不等於全部內容")

    # 2～7：房間對話，青害羞、棠正常。
    scene room
    show c shy at demo_c_portrait(0.0)
    show t nom at demo_t_portrait(-0.25)
    window show

    show c shy at demo_c_portrait(0.0)
    show t nom at demo_t_portrait(-0.25)
    voice "audio/我先走了.ogg"
    c "我先走了。"
    show c shy at demo_c_portrait(-0.25)
    show t nom at demo_t_portrait(0.0)
    voice "audio/不洗個澡再走嗎？你這副樣子….ogg"
    t "不洗個澡再走嗎。你這幅樣子⋯⋯。"
    show c shy at demo_c_portrait(0.0)
    show t nom at demo_t_portrait(-0.25)
    voice "audio/再見.ogg"
    c "再見。"
    show c shy at demo_c_portrait(-0.25)
    show t nom at demo_t_portrait(0.0)
    voice "audio/呃…加個聯絡方式？.ogg"
    t "額⋯⋯加個聯絡方式⋯⋯？"
    show t nom at demo_t_portrait(-0.25)
    show c shy at demo_c_exit
    voice "audio/不了.ogg"
    c "不了。"
    hide c
    show t nom at demo_t_portrait(0.0)
    voice "audio/那來點點今天的營業額好了.ogg"
    t "那來點點今天的營業額好了"

    # 8：點硬幣小遊戲。
    call play_coin_game

    # 9：CG 進場動畫與音效。
    window hide None
    scene black
    play sound "audio/cg01.ogg"
    scene cg01
    $ renpy.music.play("images/cg01.webm", channel="demo_cg_video", loop=False)
    $ renpy.music.queue("images/GIF01.webm", channel="demo_cg_video", loop=True, clear_queue=False)
    call screen demo_wait_cg_intro
    stop sound

    # 10～11：CG 循環背景上的對話。
    # GIF 已由播放佇列接上，沿用目前畫面。
    window show None
    voice "audio/我今天的營業額對不起來啊？.ogg"
    t "我今天營業額對不起來啊⋯⋯。"
    voice "audio/應該是酒醉的小水母沒給錢.ogg"
    t "應該是酒醉的小水母沒給錢⋯⋯。"

    # 12：結尾跑馬燈。切換場景也會移除 CG 影片。
    window hide
    $ renpy.music.stop(channel="demo_cg_video")
    scene black
    call demo_show_marquee("最新消息請至官網查詢")
    return
