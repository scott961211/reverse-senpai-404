﻿# 遊戲腳本位於此檔案。

# 宣告該遊戲使用的角色。 color 參數
# 為角色的名稱著色。

define t = Character("棠")
define y = Character("癒")
define c = Character("青")

image t = Placeholder("girl", text="棠")
image y = Placeholder("boy", text="癒")
image c = Placeholder("boy", text="青")

define pls = Character("警察")
define p = Character("旁白")
define data1 = Character("下課鐘聲")

#文字區---------------------------------------------
image 98 = Text(
    "酒吧",
    size = 200,
    color = "#999999",
    outlines=[(2, "#999999", 0, 0)]
)

image drinking = Text(
    "一陣暢飲後",
    size = 200,
    color = "#999999",
    outlines=[(2, "#999999", 0, 0)]
)

image moring = Text(
    "清晨",
    size = 200,
    color = "#999999",
    outlines=[(2, "#999999", 0, 0)]
)

image gobake = Text(
    "回到宿舍門口",
    size = 200,
    color = "#999999",
    outlines=[(2, "#999999", 0, 0)]
)

#角色入場定位---------------------------------------
transform to_left_1:
    xalign 0.0
    yalign 1.0
    linear 1.0 xalign 0.15

transform to_right_1:
    xalign 1.0
    yalign 1.0
    linear 1.0 xalign 0.85

transform to_right_2:
    xalign 1.0
    yalign 1.0
    linear 1.0 xalign 0.7

#文字區---------------------------------------------
transform text_move1:
    xalign -2.5
    yalign 0.5
    linear 1.0 xalign 0.5

transform text_move2:
    linear 1.0 xalign 3.0

#第一段癒追青---------------------------------------
transform y_y_goto_c:
    linear 1.5 xalign 1.3

transform c_y_goto_c:
    linear 1.0 xalign 1.3

#98
transform y_out_fast:
    linear 0.5 xalign 1.3

transform c_sleep:
    linear 1.0 rotate -90 xalign 1.2 yalign 0.0

transform c_wakeup:
    linear 1.0 rotate 0 xalign 1.35 yalign 1.0

transform c_out_thome:
    linear 1.0 xalign 2.5


# 遊戲從這裡開始。

label start:

    data1 "當~~當~~當~~當~~"

    p "下課鐘聲響起，今天的癒反常地問"

    show y at to_left_1

    y "喂，今晚⋯⋯要不要去喝一杯⋯⋯"
    y "難得喔我今天想喝酒，不然我怕你那小身板會被一群男的拐走去賣屁股。"

    show c at to_right_1

    c "三小，那那群男的也是很不長眼了"
    c "你爹我身材這麼『高大（165）』"
    y "你媽O。到底要不要去喝？"
    c "喔，隨便。"
    y "幹在那邊打謎語猜的很躁耶。"

    show c at c_y_goto_c
    show y at y_y_goto_c

    y "不管你給我滾過來你這個侏儒"

    window hide

    show 98 at text_move1
    pause 2.0
    show 98 at text_move2
    pause 1.5

    window show
    show c at to_right_1

    c "蜂蜜酒。"

    show t at to_left_1

    t "弟弟這裡是酒吧你未滿18不能喝⋯⋯"
    c "（遞身分證）"
    t "沒有啦⋯⋯我開玩笑的啦⋯⋯對不起。"

    show y at to_right_2

    y "笑死，沒事啦他已經習慣了"
    y "（咕嚕咕嚕咕嚕。）"

    hide c
    hide y
    hide t

    window hide

    show drinking at text_move1
    pause 2.0
    show drinking at text_move2
    pause 1.5

    window show

    show c at to_right_1

    c "泥蒸的，泥爹能夠在齁一杯⋯⋯"

    show y at to_right_2

    y "喂幹你酒量不好在喝三小啦"
    y "你為什麼不去喝3%%的水果酒"

    c "......"
    c "(趴在吧檯睡著了)"

    #------------------------------------------------------------------
    #預計會撥放動畫
    #------------------------------------------------------------------

    hide c
    hide y

    "柔順的長髮藉著燈光和玻璃杯的交織在發光"

    show c
    show y

    y "好騷(舔嘴唇)"

    show t at to_left_1

    t "先生⋯⋯我還在這裡呢⋯⋯。"
    y "⋯⋯我去租車把他帶回家吧"
    y "不好意思造成您的麻煩了"
    t "沒事沒事⋯⋯習慣了。"
    y "(帶著錢包就出去酒吧的門了。)"

    show y at y_out_fast

    c "(酒沒醒，但是跌跌撞撞的起來了。)"
    t "喂，你的酒還沒全醒"
    t "但你目前安全了⋯⋯"
    t "那個看起來很怪的怪叔叔已經被我支開了"
    c "⋯⋯與我有什麼關係"
    c "我要回家!!!"
    c "(推開酒吧的門。)"
    t "???"
    "外面下著大雨。"
    c "嗚⋯⋯紐約下大雨了⋯⋯"
    c "我是沒有人要的呱呱（孤寡）老人"
    t "⋯⋯?"
    t "你還好嗎⋯⋯?"
    "一道聲音傳來"
    "那位的衣著打扮像極了先生。看起來很有安全感。"
    c "爸爸⋯⋯!爸爸⋯⋯!"
    c "我在紐約很想你⋯⋯。"
    c "爸爸快點帶我回家⋯⋯"
    c "(哼哧哼哧)"
    c "我不想回紐約了⋯⋯"
    t "(不知道這個小朋友的電話，先找一個地方安置一下好了。)"
    t "(現在台灣人的生態基本上都是先錄影。畢竟我也是第一次遇見小朋友發酒瘋發到直接喊調酒師爸爸的)"
    "帶回了棠的住所(其實在酒館樓上)"

    show c at c_sleep

    c "嗚呼軟綿綿的大床!!!"
    t "?"
    c "沉沉的睡去了。"
    t "對吼我們有警察⋯⋯"
    t "額⋯⋯我相信酒醉會醒的讓他自己離開吧。"

    hide c
    hide t

    window hide

    show moring at text_move1
    pause 2.0
    show moring at text_move2
    pause 1.5

    window show

    show c at c_wakeup

    c "恩?"
    c "我不是在宿舍嗎?"
    c "床不應該硬到靠北嗎?"

    show t at to_left_1

    t "你醒啦?"
    c "?"
    c "你對我怎麼了。"
    t "我看見您在路邊大叫、嘶吼"
    t "而且我怕那個很怪的怪叔叔回來"
    t "就把你安置到我的私人住所了。"
    c "蛤?"
    t "額對，你那個時候的狀態超級無敵像一隻發狂的野獸"
    t "我有錄下來喔。"
    c "。。。"
    t "(給青看錄影)"
    c "(臉變超紅)"
    c "我先走了......"
    t "不洗個澡再走嗎。你這幅樣子⋯⋯。"
    c "再見。"
    t "額⋯⋯加個聯絡方式⋯⋯？"
    c "不了。"

    show c at c_out_thome

    hide t

    window hide

    show gobake at text_move1
    pause 2.0
    show gobake at text_move2
    pause 1.5

    window show

    show c at to_left_1

    c "又丟臉又生氣"
    c "我本來就沒氣質了還要這樣搞我"
    c "你O的室友在那邊烏鴉嘴"
    "(在宿舍門口，看到了警察)"
    c "蛤?"

    show y at to_right_1
    show pls at to_right_2

    y "我的室友⋯⋯酒量很差⋯⋯"
    y "我去租車⋯⋯租不到⋯⋯"
    y "然後我就想說⋯⋯背他回去⋯⋯"
    y "因爲⋯⋯他超級無敵瘦⋯⋯像一個女的⋯⋯"
    y "然後我就找不到他了⋯⋯我的室友啊⋯⋯"
    y "哼哧哼哧哼哧⋯⋯"
    pls "成年人失蹤立案需要24小時喔"
    c "......"
    c "不好意思，我沒事了⋯⋯不好意思浪費了你們的寶貴時間"
    pls "沒事沒事，為民服務是應該的。"

    show pls at y_out_fast

    "警察走後"
    c "哩洗勒考喔"
    y "幹你O你知道我有多擔心你嗎"
    y "我剛以為我烏鴉嘴發作你真的去賣屁股了"
    c "我真的差點被賣屁股。"
    y "額⋯⋯"
    c "?"
    y "兄弟⋯⋯你好臭"
    c "我去洗澡。"
    y "行。我兒子沒事就好。"
    c "......"

    hide c
    hide y

    "在棠的住所"
    
    #------------------------------------------------------------------
    #預計會撥放動畫
    #------------------------------------------------------------------

    "我今天營業額對不起來啊⋯⋯。"
    "應該是酒醉的小水母沒給錢⋯⋯。"

    return

